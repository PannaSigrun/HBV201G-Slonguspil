package vidmot;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import vinnsla.Leikur;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SlangaController implements Initializable {

    @FXML
    private GridPane fxBord;
    @FXML
    private Label fxSkilabod1;
    @FXML
    private Label fxSkilabod2;
    @FXML
    private Button fxNyrLeikurButton;
    @FXML
    private Button fxTeningurButton;

    private Leikur leikur;
    private List<Node> reitir; //Tilviksbreyta fyrir reitina
    private static final String[] myndir = {"one", "two", "three", "four", "five", "six"};

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        leikur = new Leikur(24);
        reitir = fxBord.getChildren(); //Röðin er sú sama og í fxml skránni

        //Binda fxNyrLeikur disableProperty við stöðuna á leiknum (leik lokið eða ekki) í Leikur
        fxNyrLeikurButton.disableProperty().bind(leikur.leikLokidProperty().not());

        //Binda fxTeningur diableProperty við fxNyrLeikur disableProperty
        fxTeningurButton.disableProperty().bind(fxNyrLeikurButton.disableProperty().not());

        //Binda fxTeningur við töluna á teningnum við myndina sem birtist á teningnum
        //Listener fyrir teninginn
        leikur.getTeningur().addListener(
                (observable, oldValue, newValue) ->
                {
                    fxTeningurButton.getStyleClass().remove(myndir[oldValue.intValue() - 1]);
                    fxTeningurButton.getStyleClass().add(myndir[newValue.intValue() - 1]);
                }
        );
    }

    @FXML
    protected void nyrLeikurHandler(ActionEvent event) {
        leikur.nyrLeikur();
    }

    @FXML
    protected void teningurHandler(ActionEvent event) {
        leikur.leikaLeik();
    }
}