package vinnsla;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Leikur {
    private int MAX_REITIR;
    private Leikmadur leikmadur1;
    private Leikmadur leikmadur2;
    private Teningur teningur;
    private SlongurStigar slongurOgStigar;
    private final SimpleBooleanProperty leikLokid = new SimpleBooleanProperty(true);
    private final SimpleStringProperty sigurvegari = new SimpleStringProperty();
    private final SimpleIntegerProperty hverAAdGera = new SimpleIntegerProperty();
    private final SimpleStringProperty slangaEdaStigi = new SimpleStringProperty();

    public Leikur(int fljoldiReita) {
        MAX_REITIR = fljoldiReita;
        leikmadur1 = new Leikmadur("Leikmadur1");
        leikmadur2 = new Leikmadur("Leikmadur2");
        teningur = new Teningur();
        slongurOgStigar = new SlongurStigar();
    }

    /**
     * Hefur nýjan leik. Leikmenn settir á reit eitt
     */
    public void nyrLeikur() {
        leikmadur1.faera(1, MAX_REITIR);
        leikmadur2.faera(1, MAX_REITIR);
        hverAAdGera.set(1);
        leikLokid.set(false);
    }

    /**
     * Kastar tening, færir leikmann, setur næsta leikmann
     *
     * @return skilar true ef leik er lokið
     */
    public boolean leikaLeik() {
        teningur.kasta();
        if (hverAAdGera.get() == 1) {
            faeraLeikmann(leikmadur1);
            slangaEdaStigi.set(erSlangaEdaStigi(leikmadur1));
            erLeikmadurSigurvegar(leikmadur1);
            hverAAdGera.set(2);
        }
        else if (hverAAdGera.get() == 2) {
            faeraLeikmann(leikmadur2);
            slangaEdaStigi.set(erSlangaEdaStigi(leikmadur2));
            erLeikmadurSigurvegar(leikmadur2);
            hverAAdGera.set(1);
        }
        return leikLokid.get();
    }

    /**
     * Færir leikmann á næsta reit
     * @param leikmadur leikmaður sem á að færa
     */
    public void faeraLeikmann(Leikmadur leikmadur) {
        int nyrReitur = leikmadur.getStada() + teningur.getTeningur();
        leikmadur.faera(nyrReitur, MAX_REITIR);
    }

    /**
     * Athugar hvort það sé slanga eða stigi á reitnum sem leikmaðurinn stendur á
     * @param leikmadur leikmaður sem á að færa
     */
    public String erSlangaEdaStigi(Leikmadur leikmadur) {
        int nyrReitur = slongurOgStigar.athugaReit(leikmadur.getStada());
        if (nyrReitur < leikmadur.getStada() && nyrReitur != 0) {
            leikmadur.faera(nyrReitur, MAX_REITIR);
            return "slanga";
        } else if (nyrReitur > leikmadur.getStada()) {
            leikmadur.faera(nyrReitur, MAX_REITIR);
            return "stigi";
        }
        return "";
    }

    /**
     * Athugar hvort leikmaður sé sigurvegari
     * @param leikmadur leikmaður sem á að athuga
     */
    public void erLeikmadurSigurvegar(Leikmadur leikmadur) {
        if (leikmadur.getStada() == MAX_REITIR) {
            leikLokid.set(true);
            sigurvegari.set(leikmadur.getNafn());
        }
    }

    /**
     * Skilar nafni sigurvegara sem String breytu
     * @return nafn leikmanns
     */
    public String getSigurvegari() {
        return sigurvegari.get();
    }

    /**
     * Skilar booelan property sem segir til um hvort leik sé lokið
     * @return leikLokið SimpleBooleanProperty
     */
    public SimpleBooleanProperty leikLokidProperty() {
        return leikLokid;
    }

    /**
     * Skilar leikmanni 1 eða 2
     * @param i annað hvort 1 eða 2
     * @return leikmaður
     */
    public Leikmadur getLeikmadur(int i) {
        if (i == 1) {
            return leikmadur1;
        }
        else if (i == 2){
            return leikmadur2;
        }
        else {
            return null;
        }
    }

    /**
     * Skilar simple integer property teningsins
     * @return SimpleIntegerProperty
     */
    public SimpleIntegerProperty getTeningur() {
        return teningur.getTeningurProperty();
    }

    public static void main(String[] args) {
        Leikur leikur = new Leikur(24);
        leikur.nyrLeikur();
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        System.out.print("Á næsti leikmaður að gera? ");
        String svar = scanner.next();
        while ("j".equalsIgnoreCase(svar)) {
            if (leikur.leikaLeik()) {
                System.out.println("Leikmaður 1: " + leikur.leikmadur1.getStada() + "   Leikmaður 2: " + leikur.leikmadur2.getStada());
                System.out.println(leikur.getSigurvegari() + "kominn í mark");
                return;
            }
            System.out.println("Teningur: " + leikur.teningur.getTeningur() + "   " + leikur.slangaEdaStigi.get());
            System.out.println("Leikmaður 1: " + leikur.leikmadur1.getStada() + "   Leikmaður 2: " + leikur.leikmadur2.getStada());
            System.out.print("Á næsti leikmaður að gera?");
            svar = scanner.next();
        }
    }
}
